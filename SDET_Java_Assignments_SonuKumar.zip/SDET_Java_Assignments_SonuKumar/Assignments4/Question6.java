package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments4;

//6. Get highest and lowest value stored in TreeSet

import java.util.TreeSet;
public class Question6 {
    public static void main(String[] args) {
        TreeSet<Integer> set=new TreeSet<Integer>();
        set.add(300);
        set.add(500);
        set.add(-39);
        set.add(-60);
        System.out.println("Lowest Value: "+set.pollFirst());
        System.out.println("Highest Value: "+set.pollLast());
    }
}
