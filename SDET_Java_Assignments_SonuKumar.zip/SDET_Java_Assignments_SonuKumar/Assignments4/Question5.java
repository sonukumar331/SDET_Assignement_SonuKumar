package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments4;

//5. Copy all elements of a HashSet to an Object array.

import java.util.HashSet;
import java.util.Set;

public class Question5 {
    public static void main(String[] args) {
        Set<Integer> hs = new HashSet<Integer>();
        hs.add(25);
        hs.add(64);
        hs.add(73);
        hs.add(75);
        hs.add(77);
        hs.add(80);
        hs.add(85);
        hs.add(89);
        System.out.println("Elements in set = "+hs);
        System.out.println("Copying all elements...");
        Object[] obArr = hs.toArray();
        for (Object ob : obArr)
            System.out.println(ob);

    }
}