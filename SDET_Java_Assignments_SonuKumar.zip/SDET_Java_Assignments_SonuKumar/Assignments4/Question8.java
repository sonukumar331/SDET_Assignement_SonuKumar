package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments4;

//8. Get Set view of keys from HashTable.
import java.util.Enumeration;
import java.util.Hashtable;

public class Question8 {
    public static void main(String[] args) {
        Hashtable ht = new Hashtable();
        ht.put("1", "OneMan");
        ht.put("2", "TwoMan");
        ht.put("3", "ThreeMen");
        Enumeration e = ht.keys();

        while (e.hasMoreElements()) {
            System.out.println(e.nextElement());
        }
    }
}
