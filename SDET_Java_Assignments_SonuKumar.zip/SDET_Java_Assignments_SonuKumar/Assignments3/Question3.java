package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments3;

//3. Write a program to check “brown” is present in the string: A brown fox
//        ran away fast

public class Question3 {
    public static void main(String[] args) {
        String txt = " A brown fox ran away fast";
        String str1 = " brown";
        String str2 = " brown1";
        // check if name is present in text
        boolean result = txt.contains(str1);
        if(result) {
            System.out.println(str1 + " is present in the string.");
            }
        else {
            System.out.println(str1 + " is not present in the string.");
            }
        result = txt.contains(str2);
        if(result) {
            System.out.println(str2 + " is present in the string.");
            }
        else {
            System.out.println(str2 + " is not present in the string.");
            }
        }
}
