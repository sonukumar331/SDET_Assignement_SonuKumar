package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments3;

//2. Write a program to check if a given string is a palindrome or not.
//        Palindrome example: trurt

import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
            String original, reverse = ""; // Objects of String class
            @SuppressWarnings("resource")
            Scanner in = new Scanner(System.in);
            System.out.println("Enter a string/number to check if it is a palindrome");
            original = in.nextLine();
            int length = original.length();
            for (int i = length - 1; i >= 0; i--)
                reverse = reverse + original.charAt(i);
            if (original.equals(reverse))
                System.out.println("Entered string/number is a palindrome.");
            else
                System.out.println("Entered string/number isn't a palindrome.");
    }
}
