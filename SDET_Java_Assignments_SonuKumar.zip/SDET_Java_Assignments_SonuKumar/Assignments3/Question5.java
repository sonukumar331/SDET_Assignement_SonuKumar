package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments3;

//5. Write a program to throw NumberFormatException and handle it
//        appropriately with a proper message.
//        If you pass invalid input to parseInt(str), this exception will be thrown.

public class Question5 {
    private static final String inputString = "99.99";

    public static void main(String[] args) {
        try {
            int a = Integer.parseInt(inputString);
            //System.out.println(a);
        }catch(Exception ex){
            System.err.println("Invalid string in argument");
            //request for well-formatted string
        }
    }
}