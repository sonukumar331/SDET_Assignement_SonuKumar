package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments3;

//1. Write a program to print the occurrence of each character in the String
//        “DevLabs Alliance Training”

public class Question1 {
    public static void main(String[] args) {

        String str = "DevLabs Alliance Training";
        int[] freq = new int[str.length()];
        int i, j;
        System.out.println(str);
        //Converts given string into character array
        char string[] = str.toCharArray();

        for(i = 0; i <str.length(); i++) {
            freq[i] = 1;
            for(j = i+1; j <str.length(); j++) {
                if(string[i] == string[j]) {
                    freq[i]++;

                    //Set string[j] to 0 to avoid printing visited character
                    string[j] = '0';
                }
            }
        }

        //Displays the each character and their corresponding frequency
        System.out.println("Characters and their occurance");
        for(i = 0; i <freq.length; i++) {
            if(string[i] != ' ' && string[i] != '0')
                System.out.println(string[i] + "-" + freq[i]);
        }
    }
}
