package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments3;

//4. Write a program to convert String to a character array and character array
//        to String.

public class Question4 {
    public static void main(String[] args) {
        String s1="Welcome to Programming";
        char[] ch=s1.toCharArray();
        for(int i=0;i<ch.length;i++){
            System.out.println("char at "+i+" index is: "+ch[i]);
        }

        char c='W';
        String s=Character.toString(c);
        System.out.println("String is: "+s);
    }
}
