package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments3;

//7. Write a program with nested try blocks

public class Question7 {
    public static void main(String args[]){
        try{
            try{
                System.out.println("going to divide");
                int b =39/0;
            }catch(ArithmeticException e){System.out.println(e);}

            try{
                int a[]=new int[5];
                a[5]=4;
            }catch(ArrayIndexOutOfBoundsException e){System.out.println(e);}

            System.out.println("Other Statement");
        }catch(Exception e){System.out.println("Handled");}

        System.out.println("Normal Flow..");
    }
}
