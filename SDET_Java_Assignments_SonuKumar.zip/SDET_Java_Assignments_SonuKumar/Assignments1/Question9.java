package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//9. Write a program to print only even numbers till 50.

public class Question9 {
    public static void main(String[] args){
        int num=50,p;
        System.out.println("Even number till 50 are :");
        for(int i=1;i<=50;i++){
            if(i%2==0){
                System.out.println(i);
            }
        }
    }
}
