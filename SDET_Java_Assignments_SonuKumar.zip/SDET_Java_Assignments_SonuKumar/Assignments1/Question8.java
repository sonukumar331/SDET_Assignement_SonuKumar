package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//8. Write a program to reverse the elements of an array where the array size as
//        well as the array values are entered by the user

import java.util.Scanner;

public class Question8 {
    public static void main(String[] args)
    {
        int n, res,i,j=0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter number of elements in the array:");
        n = s.nextInt();
        int array[] = new int[n];
        int rev[] = new int[n];
        System.out.println("Enter "+n+" elements ");
        for( i=0; i < n; i++)
        {
            array[i] = s.nextInt();
        }
        System.out.println("Reverse of an array is :");
        for( i=n;i>0 ; i--,j++)
        {
            rev[j] = array[i-1];
            System.out.println(rev[j]);

        }
    }
}

