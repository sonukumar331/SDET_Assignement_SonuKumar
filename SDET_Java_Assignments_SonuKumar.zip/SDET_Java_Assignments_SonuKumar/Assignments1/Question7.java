package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//7. Write a program to print the sum of the first 20 natural numbers.

public class Question7 {
    public static void main(String args[]) {

        //method that returns the sum of n natural numbers

        int sum = 0, num = 20;
        //executes until the condition becomes false
        for (int j = 1; j <= num; j++)
            sum = sum + j;

        //calling method and prints the sum
        System.out.println("Sum of Natural Numbers is: "+sum);
    }
}
