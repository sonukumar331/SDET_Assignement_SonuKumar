package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//1. Write a program to calculate the factorial of a number using a while loop.
//        The factorial of a positive number n is given by:
//        factorial of n (n!) = 1 * 2 * 3 * 4 * ... * n

public class Question1 {
    public static void main(String[] args) {
        int fact = 1;
        int i = 1;
        int num = 5;
        while (i <= num) {
            fact = fact * i;
            i++;
        }
        System.out.println(" factorial of " + num + " is : " + fact);
    }
}
