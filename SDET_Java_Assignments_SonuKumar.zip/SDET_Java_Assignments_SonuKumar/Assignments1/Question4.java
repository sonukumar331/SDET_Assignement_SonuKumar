package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//4. Write a program to check whether the current year is leap year or not. Users will
//        enter a year value

import java.util.Scanner;

public class Question4 {
    public static void main(String args[]){
        int year;
        System.out.println("Enter an Year : ");
        Scanner sc = new Scanner(System.in);
        year = sc.nextInt();

        if (((year % 4 == 0) && (year % 100!= 0)) || (year%400 == 0))
            System.out.println("Specified year is a leap year");
        else
            System.out.println("Specified year is not a leap year");
    }
}
