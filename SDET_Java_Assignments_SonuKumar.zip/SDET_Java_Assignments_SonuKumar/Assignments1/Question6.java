package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//6. Write a program to calculate the area of a triangle. Users will enter the
//        values for base and height of the triangle.

import java.util.Scanner;

public class Question6 {
    public static void main(String args[])    {

        Scanner s= new Scanner(System.in);

        System.out.println("Enter the width of the Triangle:");
        double b= s.nextDouble();

        System.out.println("Enter the height of the Triangle:");
        double h= s.nextDouble();

        //Area = (width*height)/2
        double area=(b*h)/2;
        System.out.println("Area of Triangle is: " + area);
    }

}
