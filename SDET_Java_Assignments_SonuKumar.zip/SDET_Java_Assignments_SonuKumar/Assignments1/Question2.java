package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments1;

//2. Write a program to print fibonacci series (10 values).
//        A series where the next term is the sum of previous two terms. The first
//        two terms of the Fibonacci sequence is 0 followed by 1.
//        The Fibonacci sequence: 0, 1, 1, 2, 3, 5, 8, 13, 21, ...

public class Question2 {
    public static void main(String[] args){
        int num1 = 0, num2= 1, num3, i, count = 10;
        System.out.print(num1+" "+num2);
        for(i=2;i<count;++i){
            num3=num1+num2;
            System.out.print(" "+num3);
            num1=num2;
            num2=num3;
        }
    }

}
