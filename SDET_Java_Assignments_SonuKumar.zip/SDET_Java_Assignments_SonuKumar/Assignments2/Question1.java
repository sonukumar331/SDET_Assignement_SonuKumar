package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments2;

//1. Java Program to Calculate average of numbers using Array
//        Example:
//        values [] = 1, 2,3 4, 5
//        average = 3

public class Question1 {
    public static void main(String[] args) {
            double[] numArray = {1,2,3,4,5};
            double sum = 0.0;

            for (double num: numArray) {
                sum += num;
            }

            double average = sum / numArray.length;
            System.out.format("The average of numbers are: %.2f", average);
        }
}
