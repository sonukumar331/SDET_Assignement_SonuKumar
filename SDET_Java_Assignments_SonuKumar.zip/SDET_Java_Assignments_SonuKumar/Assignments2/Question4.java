package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments2;

//4. Find the sum of digits
//        Example:
//        int n = 1234;
//        output: 10

import java.util.Scanner;

public class Question4 {
    public static void main(String[] args) {
        int m=1234;
        int n,sum = 0;
        @SuppressWarnings("resource")
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number:");
        m = s.nextInt();
        while(m > 0)
        {
            n = m % 10;
            sum = sum + n;
            m = m / 10;
        }
        System.out.println("Sum of Digits are:"+sum);
    }
}
