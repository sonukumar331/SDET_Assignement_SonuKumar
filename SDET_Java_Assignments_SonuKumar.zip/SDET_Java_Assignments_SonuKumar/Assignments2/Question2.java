package com.broadridge.serenity.bdd.SDET_Java_Assignments_SonuKumar.Assignments2;

//2. Find all the odd numbers from 79 to 187

public class Question2 {

    public static void main(String[] args) {
        System.out.println("List of odd numbers are: ");
        //method calling
        displayOddNumbers(79, 187);
    }
    //method that checks the number is odd or not
    private static void displayOddNumbers(int num, int numEnd)
    {
        if(num>numEnd)
            return;
        if(num%2!=0)
        {
            //prints the odd numbers
            System.out.print(num +" ");
            //calling the method and increments the number by 2 if the number is odd
            displayOddNumbers(num + 2, numEnd);
        }
        else
        {
            //increments the number by 1 if the number is odd
            displayOddNumbers(num + 1, numEnd);
        }

    }

}


